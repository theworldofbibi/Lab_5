/*Autora: Gabrielle Baptista da Silva Fonseca - TIA: 31745547*/

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Valida_IdadeTest {
    
    Valida_Idade validaIdade;
    
     public Valida_IdadeTest() {
        validaIdade = new Valida_Idade();
    }
    
     @Test
    public void testrenov10() {
        System.out.println("TestRenovação10anos");
        assertEquals("Renovação a cada 10 anos", validaIdade.classificaIdade(20));
        assertEquals("Renovação a cada 10 anos", validaIdade.classificaIdade(49));
    }
    
    @Test
    public void testrenov5() {
        System.out.println("TestRenovação5anos");
        assertEquals("Renovação a cada 5 anos", validaIdade.classificaIdade(50));
        assertEquals("Renovação a cada 5 anos", validaIdade.classificaIdade(55));
        assertEquals("Renovação a cada 5 anos", validaIdade.classificaIdade(69));
    }
    
    @Test
    public void testrenov3() {
        System.out.println("TestRenovação3anos");
        assertEquals("Renovação a cada 3 anos", validaIdade.classificaIdade(70));
        assertEquals("Renovação a cada 3 anos", validaIdade.classificaIdade(75));
    }
    
    @Test
    public void testidadeInvalida() {
        System.out.println("TestIdadeInválida");
        assertEquals("Idade Inválida", validaIdade.classificaIdade(-2));
        assertEquals("Idade Inválida", validaIdade.classificaIdade(-40));
    }
    
}