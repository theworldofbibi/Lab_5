/*Autora: Gabrielle Baptista da Silva Fonseca - TIA: 31745547*/

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Valida_NotaTest {
    
    Valida_Nota validaNota;
    
    public Valida_NotaTest() {
        validaNota = new Valida_Nota();
    }

    @Test
    public void testnotaAlta() {
        System.out.println("TestNotaAlta");
        assertEquals("Passou", validaNota.classificaNota(10));
        assertEquals("Passou", validaNota.classificaNota(7));
    }
    
    @Test
    public void testnotaBaixa() {
        System.out.println("TestNotaBaixa");
        assertEquals("Reprovado", validaNota.classificaNota(0));
        assertEquals("Reprovado", validaNota.classificaNota(5));
        assertEquals("Reprovado", validaNota.classificaNota(3));
    }
    
    @Test
    public void testnotaInvalida() {
        System.out.println("TestNotaInválida");
        assertEquals("Nota inválida", validaNota.classificaNota(-1));
    }
    
}