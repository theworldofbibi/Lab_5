/*Autora: Gabrielle Baptista da Silva Fonseca - TIA: 31745547*/

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Valida_DataTest {
    
    Valida_Data validaData;
    
    public Valida_DataTest() {
        validaData = new Valida_Data();
    }

    @Test
    public void testdataValida() {
        System.out.println("TestDataVálida");
        assertEquals("Data válida", validaData.classificaData(1998));
        assertEquals("Data válida", validaData.classificaData(2015));
    }
    
    @Test
    public void testdataInvalida() {
        System.out.println("TestDataInválida");
        assertEquals("Data inválida", validaData.classificaData(0));
        assertEquals("Data inválida", validaData.classificaData(1));
        assertEquals("Data inválida", validaData.classificaData(1800));
        assertEquals("Data inválida", validaData.classificaData(2021));
    }
    
    @Test
    public void testvalorInvalido() {
        System.out.println("TestValorInválido");
        assertEquals("Valor inválido", validaData.classificaData(-3));
    }
}