/*Autora: Gabrielle Baptista da Silva Fonseca - TIA: 31745547*/

public class Valida_Data {

    public String classificaData(int data) {
        String fnOutdata = "";

        if (data == 0 || data == 1 || (data >=0 && data < 1900) || (data >=0 && data > 2020)) {
            fnOutdata = "Data inválida";
        } 
        
        else if (data >= 1900 && data <= 2020) {
            fnOutdata = "Data válida";
        } 
        
        else if (data < 0) {
            fnOutdata = "Valor inválido";
        }

        return fnOutdata;
    }
    
}