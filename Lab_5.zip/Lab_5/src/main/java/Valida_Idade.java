/*Autora: Gabrielle Baptista da Silva Fonseca - TIA: 31745547*/

public class Valida_Idade {
    
    public String classificaIdade(int idade) {
        String fnOutidade = "";
        
        if (idade < 0) {
            fnOutidade = "Idade Inválida";
        }
        
        else if (idade < 50 && idade > 0) {
            fnOutidade = "Renovação a cada 10 anos";
        }
        
        else if (idade >= 50 && idade < 70)  {
            fnOutidade = "Renovação a cada 5 anos";
        }
        
        else if (idade >= 70) {
            fnOutidade = "Renovação a cada 3 anos";
        }
        
        return fnOutidade;
    }
    
}