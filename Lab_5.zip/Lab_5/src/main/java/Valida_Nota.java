/*Autora: Gabrielle Baptista da Silva Fonseca - TIA: 31745547*/

public class Valida_Nota {
    
    public String classificaNota(int nota) {
        String fnOutnota = "";

        if (nota < 0) {
            fnOutnota = "Nota inválida";
        } 
        
        else if (nota == 0 || nota <= 5) {
            fnOutnota = "Reprovado";
        } 
        
        else if (nota > 5 && nota <= 10) {
            fnOutnota = "Passou";
        }

        return fnOutnota;
    }
    
}